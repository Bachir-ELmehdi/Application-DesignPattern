package Factory;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Factory
 * Date    =====> 24 oct. 2019 
 */
public class EnemyFactory {
 
	
	public  static final int BIRD =1;
	public static final int Turle= 2;
	/**
	 * @param args
	 * @return 
	 */
	public static 	Enemy creatEnemy(int id) {
		switch(id) {
		case BIRD:
			return new Bird();
		case Turle :
			return new Turle();
		default:
			return null;
		}
	}
	

}
