package Factory;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Factory
 * Date    =====> 24 oct. 2019 
 */
public class Bird  extends Enemy{
		/**
		 * 
		 */
		public Bird() {
			// TODO Auto-generated constructor stub
	       
			setName("bird");
			setDamge(5);
			setHealth(60);
		
		}

}
