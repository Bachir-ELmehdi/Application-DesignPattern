package Factory;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Factory
 * Date    =====> 24 oct. 2019 
 */
    public  abstract class Enemy  extends EnemyFactory{
	private String name;
	private int damge;
	private int health;
	 /**
	 * 
	 */
	public Enemy() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the damge
	 */
	public int getDamge() {
		return damge;
	}/**
	 * @return the health
	 */
	public int getHealth() {
		return health;
	}/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param damge the damge to set
	 */
	public void setDamge(int damge) {
		this.damge = damge;
	}
	/**
	 * @param health the health to set
	 */
	public void setHealth(int health) {
		this.health = health;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	public void showUp() {
		System.out.println(name+" is showing up , Damge is"+getDamge()+" Health is "+ getHealth());
	}

}
