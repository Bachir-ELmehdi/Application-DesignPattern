package Factory;

import java.util.Random;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Factory
 * Date    =====> 24 oct. 2019 
 */
public class Games {
	static Random rand = new Random();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int loop=5;
				while(loop>0) {
					Enemy e =  EnemyFactory.creatEnemy(getRandom(1,2));
					e.showUp();
					loop--;
				}
		
	}
	public static int getRandom(int min , int max) {
		return rand.nextInt( (max-min)+1)+min;
	}

}
