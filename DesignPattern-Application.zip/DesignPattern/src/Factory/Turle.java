package Factory;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Factory
 * Date    =====> 24 oct. 2019 
 */
public class Turle extends Enemy{

	/**
	 * 
	 */
	public Turle() {
		// TODO Auto-generated constructor stub
		setName("truale");
		setDamge(3);
		setHealth(40);
	}
}
