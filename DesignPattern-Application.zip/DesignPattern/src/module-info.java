module DesignPattern {
}