package StatePatern;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> StatePatern
 * Date    =====> 5 nov. 2019 
 */
public class Test {
    private static State state;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("marhba");
		Computer com = new Computer();
	   Start s = new Start();
       Stop p = new Stop();
        s.action(com);       
        p.action(com);
       
	}
	
}
