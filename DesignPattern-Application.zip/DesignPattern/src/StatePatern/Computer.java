package StatePatern;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> StatePatern
 * Date    =====> 5 nov. 2019 
 */
public class Computer  implements State{
	private State state;

	@Override
	public void action(Computer com) {
		// TODO Auto-generated method stub
		state.action(com);
		
	}
	/**
	 * @param state the state to set
	 */
	public void setState(State state) {
		this.state = state;
	}

}
