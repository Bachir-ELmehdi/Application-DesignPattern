package StatePatern;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> StatePatern
 * Date    =====> 5 nov. 2019 
 */
public class Start  implements State{

	@Override
	public void action(Computer com) {
		// TODO Auto-generated method stub
		System.out.println("Computer Start");
		com.setState(this);
		
	}

}
