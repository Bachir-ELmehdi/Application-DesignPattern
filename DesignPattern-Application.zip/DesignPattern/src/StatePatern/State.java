package StatePatern;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> StatePatern
 * Date    =====> 5 nov. 2019 
 */
public interface State {
	public void action(Computer com);

}
