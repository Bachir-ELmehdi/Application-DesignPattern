package StatePatern;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> StatePatern
 * Date    =====> 5 nov. 2019 
 */
public class Stop implements State {

	@Override
	public void action(Computer com) {
		// TODO Auto-generated method stub
		
		com.setState(this);
		System.out.println("Computer Stop");
	}

}
