package Adapter;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Adapter
 * Date    =====> 23 oct. 2019 
 */
public class Car implements Vehicle {

	@Override
	public void accelearte() {
		// TODO Auto-generated method stub
		System.out.println("Car Start to move");
	}

	@Override
	public void pushBreak() {
		// TODO Auto-generated method stub
		System.out.println("car stopped");
	}

	@Override
	public void soundHorn() {
		// TODO Auto-generated method stub
		System.out.println("Beep Beep");
	}

}
