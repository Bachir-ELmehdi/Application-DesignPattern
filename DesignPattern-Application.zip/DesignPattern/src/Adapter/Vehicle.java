package Adapter;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Adapter
 * Date    =====> 23 oct. 2019 
 */
public interface Vehicle {
	void accelearte ();
	void pushBreak();
	void soundHorn();

}
