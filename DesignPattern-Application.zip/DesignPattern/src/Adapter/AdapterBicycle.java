package Adapter;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Adapter
 * Date    =====> 23 oct. 2019 
 */
public class AdapterBicycle implements Vehicle{
private Bicycle b = new Bicycle();
	/**
 * @param bicycle
 */
public AdapterBicycle(Bicycle bicycle) {
	// TODO Auto-generated constructor stub
	b=bicycle;
}

	@Override
	public void accelearte() {
		// TODO Auto-generated method stub
		b.pedal();
	}

	@Override
	public void pushBreak() {
		// TODO Auto-generated method stub
		b.stop();
	}

	@Override
	public void soundHorn() {
		// TODO Auto-generated method stub
		b.ringBell();
	}

}
