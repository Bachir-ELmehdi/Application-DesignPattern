package Adapter;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Adapter
 * Date    =====> 23 oct. 2019 
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Vehicle   car = new Car();
     Vehicle b = new AdapterBicycle(new Bicycle());
	     playWithVehicle(car);
         playWithVehicle(b);
	}
	public  static void playWithVehicle(Vehicle care) {
		care.accelearte();
		care.pushBreak();
		care.soundHorn();	
	}

}
