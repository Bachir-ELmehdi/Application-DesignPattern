package Adapter;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Adapter
 * Date    =====> 23 oct. 2019 
 */
public class Bicycle {
	public void pedal() {
		System.out.println("Bic start To move");
	}
	public void stop() {
		System.out.println("bic stopped");
	}
	public void ringBell() {
		System.out.println("Ring ring");
	}

}
