package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
 public class Tv {
		public void turnOn() {
			System.out.println("Tv Is On");
		}
	   public void turnOff() {
		   System.out.println("Tv  is off");
	   }

}
