package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class Clinet {
  
	public static void main(String[] args) {
		Light light = new Light();
		TurnOnLightCommande turnOnLightCommande = new TurnOnLightCommande(light);
		TurnOffLightCommande turnoffLightCommande = new TurnOffLightCommande(light);
		Tv tv = new Tv();
		TurnOnTvCommand turnOnTvCommand = new TurnOnTvCommand(tv);
		TurnOffTvCommande turnOffTvCommand = new TurnOffTvCommande(tv);
		RemoteControler remote = new RemoteControler();
		remote.AddCommand(0, turnOnLightCommande, turnoffLightCommande);
		remote.AddCommand(1, turnOnTvCommand, turnOffTvCommand);
		
		System.out.println(remote);
		remote.onButtonPressed(0);
		
		remote.offButtonPressed(0);
		
		remote.onButtonPressed(1);
		
		remote.offButtonPressed(1);
		remote.toString();
		
		
		
		System.out.println("//////////////////////////////////");
		
		remote.undoButtonPressed();
		remote.undoButtonPressed();
		remote.undoButtonPressed();
		remote.undoButtonPressed();
		remote.undoButtonPressed();
		remote.undoButtonPressed();

	}
}
