package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
//Receiver
public class Light {
	public void turnOn() {
	System.out.println("Light is On");
}
public void turnOff() {
   System.out.println("Light  is off");
}




}
