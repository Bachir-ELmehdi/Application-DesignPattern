	package Commande;

import java.util.LinkedList;



/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class RemoteControler {
	private  Commande[] OnCommand;
	private Commande[] OffCommand;
	 private LinkedList <Commande> history;
	
	/**
	 * 
	 */
	public RemoteControler() {
		// TODO Auto-generated constructor stub
		this.OnCommand = new Commande[3];
		this.OffCommand =  new Commande[3];
					history = new LinkedList<>();
		NoCommande noCommande = new NoCommande();
		for(int i =0;i<OnCommand.length;i++) {
			OnCommand[i] = noCommande;
			OffCommand[i] = noCommande;
		}
	}
	
	public void AddCommand(int slot, Commande oncommand,Commande offcommand) {
		OnCommand[slot] = oncommand;
		OffCommand[slot] = offcommand;
		
	}
	public void onButtonPressed(int slot) {
		OnCommand[slot].execute();
		history.push(OnCommand[slot]);
	}
	public void offButtonPressed(int slot) {
		OffCommand[slot].execute();
		history.push(OffCommand[slot]);

	}
	
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer(10);
		for(int i=0; i< OnCommand.length;  i++) {
		buffer.append(String.format("[slot : %d] %s\t  %s%n", i, OnCommand[i].getClass().getSimpleName(),OffCommand[i].getClass().getSimpleName()));
		
		}
		return buffer.toString();
	}
	public void undoButtonPressed()
	{
		if(history.peek() != null) {
			history.poll().undo();
			
		}else {
			System.out.println("No More History");
		}
	}
}
