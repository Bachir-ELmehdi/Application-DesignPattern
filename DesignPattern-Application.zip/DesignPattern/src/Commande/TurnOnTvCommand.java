package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class TurnOnTvCommand  implements Commande{
	private Tv tv ;

	/**
	 * 
	 */
	public TurnOnTvCommand(Tv tv)
	{
		this.tv =tv;
		// TODO Auto-generated constructor stub
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		tv.turnOn();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		tv.turnOff();
		
	}
	
	
}
