package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class TurnOnLightCommande  implements Commande{
   private Light light ;
   
	public TurnOnLightCommande(Light light) {
		// TODO Auto-generated constructor stub
		this.light = light;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		light.turnOn();
	
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		light.turnOff();
	}
	

}
