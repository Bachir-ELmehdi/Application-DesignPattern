package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class TurnOffTvCommande  implements Commande{
private Tv tv = new Tv();
/**
 * 
 */
public TurnOffTvCommande(Tv tv) {
	// TODO Auto-generated constructor stub
	this.tv=tv;
}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		tv.turnOff();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		tv.turnOn();
	}

}
