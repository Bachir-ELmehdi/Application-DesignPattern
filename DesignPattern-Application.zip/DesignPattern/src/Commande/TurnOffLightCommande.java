package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class TurnOffLightCommande implements Commande {
private Light light;

	public TurnOffLightCommande(Light light) {
		// TODO Auto-generated constructor stub
		this.light = light;
	}
	public void execute() {
		// TODO Auto-generated method stub
		light.turnOff();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		light.turnOn();
	}

}
