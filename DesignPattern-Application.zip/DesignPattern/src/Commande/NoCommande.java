package Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Commande
 * Date    =====> 25 oct. 2019 
 */
public class NoCommande implements Commande{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
