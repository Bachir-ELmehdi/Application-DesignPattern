package Singleton;

 import java.util.*;
public class lazySingleton {

	private String[] LETTERS = {"a","b","c","d"};
	private List<String>data = Arrays.asList(LETTERS);
	private static	lazySingleton Instance;
	private lazySingleton()
	{
		Collections.shuffle(data);
	}
	public static lazySingleton getInstance()
	{
		if(Instance == null)
		{
			Instance = new lazySingleton();
		}
		return Instance;
	}
	
	public void printData()
	{
		for(String item :data)
		{
			System.out.printf("%s ", item);
		}
		System.out.println();
	}
	
}
