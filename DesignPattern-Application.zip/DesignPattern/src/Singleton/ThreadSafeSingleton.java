package Singleton;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ThreadSafeSingleton {

	
	private String[] LETTERS = {"a","b","c","d"};
	private List<String>data = Arrays.asList(LETTERS);
	private static	volatile ThreadSafeSingleton Instance;
	private static boolean delayMe = true;
	private ThreadSafeSingleton()
	{
		Collections.shuffle(data);
	}
	public static synchronized ThreadSafeSingleton getInstance()
	{
		if(Instance == null)
		{   if(delayMe)
		{
			delayMe=false;
			Thread.currentThread();
			try {Thread.sleep( 1000);}catch(InterruptedException ie) {}
				
			}
		}
			Instance = new ThreadSafeSingleton();
		
		return Instance;
	}
	
	
	public void printData()
	{
		for(String item :data)
		{
			System.out.printf("%s ", item);
		}
		System.out.println();
	}
	
}
