package Singleton;

public class Driver {

	public static void main(String[] args) {
						// TODO Auto-generated method stub
//				lazySingleton l1 =  lazySingleton.getInstance();
//				lazySingleton l2 =  lazySingleton.getInstance();
//				
//				l1.printData();
//				 System.out.println(l1.hashCode());
//				l2.printData();
//				System.out.println(l2.hashCode());	
		new DataPrinter().start();
		
		new DataPrinter().start();
    }
}
	
	 class DataPrinter extends Thread {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ThreadSafeSingleton.getInstance().printData();
		}

	

}
