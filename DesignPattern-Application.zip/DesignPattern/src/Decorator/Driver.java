package Decorator;
import java.util.*;
import java.util.Comparator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Decorator
 * Date    =====> 21 oct. 2019 
 */
public class Driver  {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Sandwich  s = new  Fool((new BasicSandwich()));
   System.out.printf("The Content is %s , le price %.2f ",s.GetDescription(),s.GetCost());
   


	}

}
