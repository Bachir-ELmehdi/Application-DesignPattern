package Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Decorator
 * Date    =====> 21 oct. 2019 
 */
public class Tacos  extends SandwichDecorator{
	/**
	 * 
	 */
	public Tacos(Sandwich sandwich) {
		// TODO Auto-generated constructor stub
		super(sandwich);
	}
	@Override
	public double GetCost() {
		// TODO Auto-generated method stub
		return super.GetCost()+40;
	}@Override
	public String GetDescription() {
		// TODO Auto-generated method stub
		return super.GetDescription()+",frete";
	}

}
