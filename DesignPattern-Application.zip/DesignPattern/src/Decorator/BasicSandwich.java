package Decorator;

import java.util.function.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Decorator
 * Date    =====> 21 oct. 2019 
 */
public class BasicSandwich implements Sandwich {

	@Override
	public double GetCost() {
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public String GetDescription() {
		// TODO Auto-generated method stub
		return "Bread";
	}
	

}
