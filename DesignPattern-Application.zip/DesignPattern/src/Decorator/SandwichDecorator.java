package Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Decorator
 * Date    =====> 21 oct. 2019 
 */
public abstract  class SandwichDecorator  implements Sandwich{
  private Sandwich Sandwich;
/**
 * 
 */
public SandwichDecorator(Sandwich sand) {
	// TODO Auto-generated constructor stub
	this.Sandwich = sand;
}
@Override
	public double GetCost() {
		// TODO Auto-generated method stub
	 return 	Sandwich.GetCost();
	}
@Override
	public String GetDescription() {
		// TODO Auto-generated method stub
		return Sandwich.GetDescription();
	}
}
