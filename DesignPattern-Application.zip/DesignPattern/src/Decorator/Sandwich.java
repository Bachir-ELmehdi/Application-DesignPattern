package Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Decorator
 * Date    =====> 21 oct. 2019 
 */
public interface Sandwich {
	double GetCost();
	String GetDescription();

}
