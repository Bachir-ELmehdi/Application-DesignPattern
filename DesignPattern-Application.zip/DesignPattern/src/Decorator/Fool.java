package Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Decorator
 * Date    =====> 21 oct. 2019 
 */
public class Fool extends SandwichDecorator {
	/**
	 * 
	 */
	public Fool(Sandwich sandwich) {
		// TODO Auto-generated constructor stub
		super(sandwich);
		
	}
	@Override
	public double GetCost() {
		// TODO Auto-generated method stub
		return super.GetCost()+4.9;
	}
	
	@Override
	public String GetDescription() {
		// TODO Auto-generated method stub
		return super.GetDescription()+",Fool";
	}
    
}
