package Observer;

import java.util.*;
public class Person  implements Observer{

	
	private String name;
	private Stock commande;
	private   boolean demander;
	
	public Person(String name) {
		// TODO Auto-generated constructor stub
		this.name  =name;
		this.commande = new Stock();
		this.demander = false;
		
	}
	@Override
	public void update(String message) {
		// TODO Auto-generated method stub
		System.out.printf("%s Got new Notification:  %s\n",this.name,message);
		
	}
	
	/**
	 * @param commande the commande to set
	 */
	public void setCommande(Stock c) {
		this.commande = c;
	}
	 
  /**
 * @param demander the demander to set
 */
	public void setDemander(boolean demander,Stock c) {
		this.demander = demander;
		assert(demander == false) ; setCommande(c);
	}
	/**
	 * @return the commande
	 */
	public Stock getCommande() {
		return commande;
	}

}
