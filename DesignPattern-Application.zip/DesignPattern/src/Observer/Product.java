package Observer;
 import java.util.*;

public class Product implements Subject{
		 private String name;
		 private static int count = 0;
		 private   int id = 0;
		 private String availability;
		 private List<Observer> observerList;
		 public  Product( String name)
		 {
			 this.name = name;
			 this.id =++count;
			 this.observerList = new ArrayList<>();
		 }
		
			@Override
			public void add(Observer observer) {
				// TODO Auto-generated method stub
				this.observerList.add(observer);
			}
			
			@Override
			public void remove(Observer observer) {
				// TODO Auto-generated method stub
				this.observerList.remove(observer);
				
			}
			@Override
			public boolean equals(String name)
			{
			return this.name.equalsIgnoreCase(name);
			}
			
			@Override
			public void notifyAllObserver() {
				// TODO Auto-generated method stub
				for(Observer observer :this.observerList) {
					observer.update(availability);
				}
		     
			}
			public void setAvailability(boolean  availability) {
				this.availability = availability ? name+" Available" : name+" Not Available";
				notifyAllObserver();
			}
			/**
			 * @return the id
			 */
			public  int getId() {
				return id;
			}
		
			public String getName() {
				return name;
			}
			@Override
			public String toString() {
			// TODO Auto-generated method stub
			return "Name Product : "+this.name+" Code product : "+this.id;
			}
}
