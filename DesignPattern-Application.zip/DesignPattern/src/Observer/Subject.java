package Observer;

public interface Subject {
	
	void add(Observer observer);
	void remove(Observer observer);
	void notifyAllObserver();
	public boolean equals(Object o);
	boolean equals(String name);

}
