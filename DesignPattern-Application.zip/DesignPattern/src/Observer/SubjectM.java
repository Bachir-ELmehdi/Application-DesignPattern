//package Observer;
//
//import java.util.*;;
//
///**
// * @author =====> BACHIR ELMEHDI
// * Project =====> DesignPattern
// * Package =====> Observer
// * Date    =====> 20 oct. 2019 
// */
//    public interface SubjectM {
//    public 	void add_Produit(Product product);
////	public void remove_Product(Product product);
////	public boolean Verifier_saturation();
////	public List<Product>  command_Product(String nameProduct , int nombre );
////	public  boolean Existe_Product(Product product);
////	public List<Product> filter(String Name, int nombreProduct);
//
//	 
//}
