package Observer;
import java.util.*;
/**
 * @author =====> Bachir Elmehdi
 * Project =====> DesignPattern
 * Package =====> Observer 20 oct. 2019 
 */
//
//public class Magasin implements SubjectM {
//    private  String name;
//	private List<Product> stock;
//
//	private int nombreProductMax;
//	
//
//	public Magasin(String name,int nombre_p) {
//		// TODO Auto-generated constructor stub
//		this.name =name;
//		this.stock = new ArrayList<>();
//		this.nombreProductMax = nombre_p;
//		
//	}
//
//
//	@Override
//	public void add_Produit(Product product) {
//		// TODO Auto-generated method stub
//		   this.stock.add(product);
//	}
//  public void afficher() {
//	  System.out.println(stock);
//  }
////
//	@Override
//	public void remove_Product(Product product) {
//		// TODO Auto-generated method stub
//		
//		assert Existe_Product(product) : this.stock.remove(product);
//	}
//
//
//	@Override
//	public List<Product>  command_Product(String  nameProduct ,int nombre) {
//		// TODO Auto-generated method stub
//
//		return filter(nameProduct,nombre);
//	}
//
//
//	@Override
//	public boolean Verifier_saturation() {
//		// TODO Auto-generated method stub
//		
//		return this.stock.size()==nombreProductMax;
//		
//	}
//
//
//	@Override
//	public boolean Existe_Product(Product product) {
//		// TODO Auto-generated method stub
//		return this.stock.contains(product);
//	}
//
//
//	@Override
//	public List<Product> filter(String name, int nombreProduct) {
//		// TODO Auto-generated method stub		
//		List<Product> commande = new ArrayList<>(nombreProduct);
//		int i = 0;
//        Product p = new Product(name);
//        if(stock.contains(p) && i <= nombreProduct) {
//	       for(Product pro :this.stock)
//		       {
//		    	   assert pro.equals(name);
//		    	       commande.add(pro);
//		    	       stock.remove(pro);
//		    	       i++;
//				}
//        }
//        
//		return commande;
//	}
//	
//	public int [] indice_product(String name) {
//		
//		int [ ] tab = null;
//		int i=0;
//		for(Product p :stock) {
//		  assert p.equals(name) : tab[i] = this.stock.indexOf(p);
//		  i++;
//		  
//		}
//		return tab;
//	 }
//	
//	void printC(List<Product> p)
//	{
//		for(Product a :p) {
//         this.comm  = p;		}
//	}
//   
//    
//	 
//
//	/**
//	 * @return the comm
//	 */
//	public List<Product> getComm() {
//		return comm;
//	}
//	/**
//	 * @return the stock
//	 */
//	public List<Product> getStock() {
//		return stock;
//	}
//}
