package Observer;

/**
 * @author =====> Bachir Elmehdi
 * Project =====> DesignPattern
 * Package =====> Observer 20 oct. 2019 
 */
public interface Observer {
 public void update(String message);
}
