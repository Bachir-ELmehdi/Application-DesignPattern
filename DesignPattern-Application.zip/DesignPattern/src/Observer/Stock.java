package Observer;
import java.util.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Observer
 * Date    =====> 21 oct. 2019 
 */
public class Stock implements SubjectS {
		 private List<Product>stock;
	
		 
		public Stock() {
			// TODO Auto-generated constructor stub
			stock = new ArrayList<>();
		}		 
		@Override
		public void add(Product p) {
			stock.add(p);
		}
		public  void remove(Product p) {
			stock.remove(p);
		}
		public void removeAll(Stock c) {
			stock.removeAll(c.stock);
		}
		public void addAll(Stock c) {
			stock.addAll(c.stock);
		}
		public Stock filtrer(String name, int numbre) {
			Stock c = new Stock();
			int Numbre_of_Product =  numbreP(name);
			int numbre_autoriser = Numbre_of_Product <= numbre ?  Numbre_of_Product  : numbre ;
			for(int i= 0;i<stock.size();i++) {
					if(	stock.get(i).equals(name)) { c.add( this.stock.get(i));}
					if (c.stock.size() ==numbre) {break;}
				}
			return  c;
		}
		public int numbreP( String name) {
			int count = 0;
			for(Product p: this.stock)
			{  count= (p.equals(name)) ? count+1 : count;  }
			return count;
		}
		
		public void affiche()
		{
			for(Product p: stock) {
				System.out.println(p.toString());
			}
		}
		
		/**
		 * @return the stock
		 */
		public List<Product> getStock() {
			return stock;
		}
		
		
}
