package Observer;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DesignPattern
 * Package =====> Observer
 * Date    =====> 21 oct. 2019 
 */
public interface SubjectS {
	public void add(Product p);
	public void remove(Product p);
	public void addAll(Stock c);
	public void removeAll(Stock c);
	public void affiche();
	public Stock filtrer(String name,int nombre);
    
    
}
