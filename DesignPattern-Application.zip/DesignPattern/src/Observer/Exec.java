package Observer;
import java.util.*;
public class Exec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Product Phone = new Product("Samsung" );
Product sam= new Product("Sam" );
Product Phone3 = new Product("Samsung" );
Product Phone4 = new Product("OPPO" );
Product Phone5 = new Product("OPPO" );
//////////////////////////////////////////////////
Person reda = new Person("Reda");
Person Simo = new Person("Simo");
Person brahim = new Person("brahim");
////////////////////////////////////////////////
 Phone.add(reda);
 Phone.add(Simo);
 Phone.add(brahim);
//Phone.setAvailability(true);
//////////////////////////////////////////////////
 
 Stock s = new Stock();
 s.add(Phone5);
 s.add(Phone4);
 s.add(sam);
 s.add(Phone3);
 s.add(Phone);
 
 s.affiche();
//////////////////////////////////////////////////
 System.out.println("////////////////////////");

Stock n =s.filtrer("Samsung", 2);
n.affiche();
reda.setDemander(true, n);
System.out.println("////////////////////////");
(reda.getCommande()).affiche();
	}

}
